#!/bin/sh 
#################################################################
# $Id: install.sh,v 1.3 2017/03/21 11:23:17 robert Exp $
#################################################################

ARCH_FILE=$1
MCA_HOME=$2
MCA_SHARED=$3
MCA_PORT_BASE=$4

TMP_DIR=/tmp/mca-install-`uuidgen`

MCA_USER=mca
MCA_GROUP=mca

#################################################################
# input args
if [ `id -u` -ne 0 ] && [ `id -un` != $MCA_USER ]; then
	echo "Only root or $MCA_USER can run this installation script"
	exit 0
fi

if [ $# -lt 1 ]; then
	echo "MCA Installer - install new MCA instance from archive file"
	echo "Usage: `basename $0` <archive_path> [mca_home] [mca_shared] [port_base]"
	exit 0
fi

if [ $# -lt 2 ]; then
	MCA_HOME=/opt/mca
fi

if [ $# -lt 3 ]; then
	MCA_SHARED=/var/opt/mca
fi

if [ $# -lt 4 ]; then
	MCA_PORT_BASE=4500
fi

echo "Installing MCA..."
echo ""
echo "Archive file:     $ARCH_FILE"
echo "User:             $MCA_USER"
echo "Group:            $MCA_GROUP"
echo "Home directory:   $MCA_HOME"
echo "Shared directory: $MCA_SHARED"
echo "Port base:        $MCA_PORT_BASE"
echo ""

#################################################################
# target group
echo "Checking group..."

if [ `id -u` -eq 0 ]; then
	# root can create group
	getent group $MCA_GROUP >/dev/null 2>&1
	if [ $? -ne 0 ]; then
		echo "Creating group..."
		groupadd -g 250 $MCA_GROUP
	fi
fi

getent group $MCA_GROUP >/dev/null 2>&1
if [ $? -ne 0 ]; then
	echo "Group $MCA_GROUP not exists. Run this script as root to create it."
	exit 0
fi

echo "OK"
echo ""

#################################################################
# target user
echo "Checking user..."

if [ `id -u` -eq 0 ]; then
    # root can create user
    getent passwd $MCA_USER >/dev/null 2>&1
    if [ $? -ne 0 ]; then
        echo "Creating user..."
        useradd -u 250 -g $MCA_GROUP -c "MCA" -m $MCA_USER
    fi
fi

getent passwd $MCA_USER >/dev/null 2>&1
if [ $? -ne 0 ]; then
    echo "User $MCA_USER not exists. Run this script as root to create it."
    exit 0
fi

echo "OK"
echo ""

#################################################################
# home dir
echo "Checking home directory..."

if [ ! -d $MCA_HOME ]; then
	echo "Creating home directory..."
	mkdir -p $MCA_HOME
fi

if [ ! -d $MCA_HOME ]; then
	echo "Directory $MCA_HOME not exists. Run this script as root to create it."
	exit 0
fi

if [ "$(ls -A $MCA_HOME)" ]; then
	echo "Directory $MCA_HOME is not empty. Can not install to non empty directory."
	exit 0
fi

echo "OK"
echo ""

#################################################################
# shared dir
echo "Checking shared directory..."

if [ ! -d $MCA_SHARED ]; then
	echo "Creating shared directory..."
	mkdir -p $MCA_SHARED
fi

if [ ! -d $MCA_SHARED ]; then
	echo "Directory $MCA_SHARED not exists. Run this script as root to create it."
	exit 0
fi

if [ "$(ls -A $MCA_SHARED)" ]; then
	echo "Directory $MCA_SHARED is not empty."
	exit 0
fi

echo "OK"
echo ""

#################################################################
# extract archive
echo "Extracting archive..."

mkdir -p $TMP_DIR
tar -zxv -C $TMP_DIR -f $ARCH_FILE >/dev/null 2>&1

echo "OK"
echo ""

#################################################################
# copy to specified locations
echo "Copying files..."

cp -R $TMP_DIR/opt/mca/* $MCA_HOME
cp -R $TMP_DIR/var/opt/mca/* $MCA_SHARED

chown -R $MCA_USER:$MCA_GROUP $MCA_HOME
chown -R $MCA_USER:$MCA_GROUP $MCA_SHARED

echo "OK"
echo ""

#################################################################
# update configuration files
echo "Updating configuration..."

FILES="etc/mca.conf etc/mpkcs11.conf etc/tsa-policy.conf bin/mcaenv.sh"
MCA_HOME_SED=`echo $MCA_HOME|sed -e "s/\//\\\\\\\\\//g"`
MCA_SHARED_SED=`echo $MCA_SHARED|sed -e "s/\//\\\\\\\\\//g"`

for f in $FILES
do
	if [ -f $MCA_HOME/${f} ]; then
		sed -e "s/\/var\/opt\/mca/\[SHAREDDIR\]/g" -e "s/\/opt\/mca/\[INSTALLDIR\]/g" $MCA_HOME/${f} >$MCA_HOME/${f}.tmp
		sed -e "s/\[SHAREDDIR\]/$MCA_SHARED_SED/g" -e "s/\[INSTALLDIR\]/$MCA_HOME_SED/g" $MCA_HOME/${f}.tmp >$MCA_HOME/${f}
		rm -f $MCA_HOME/${f}.tmp
	fi
done

for p in {1..100}
do
	PORT_ORG=$((4500+${p}))
	PORT_NEW=$(($MCA_PORT_BASE+${p}))
	sed -e "s/$PORT_ORG/$PORT_NEW/g" $MCA_HOME/etc/mca.conf >$MCA_HOME/etc/mca.conf.tmp
	mv $MCA_HOME/etc/mca.conf.tmp $MCA_HOME/etc/mca.conf
done

chown -R $MCA_USER:$MCA_GROUP $MCA_HOME
chown -R $MCA_USER:$MCA_GROUP $MCA_SHARED
chmod 640 $MCA_HOME/etc/*.conf

echo "OK"
echo ""

#################################################################
# clean
rm -rf $TMP_DIR

# end
echo "Done"

# eof
